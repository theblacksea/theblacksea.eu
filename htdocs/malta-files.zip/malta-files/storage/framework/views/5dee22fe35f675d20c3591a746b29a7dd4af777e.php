<section class="content-image-full">
  <div class="image" style="background-image: url('<?php echo e(env('APP_PATH') .'img/articles/'. $data['src']); ?>');" data-aos="fade" data-aos-duration="800"></div>
  <?php if(isset($data['text'])): ?>
    <div class="text <?php echo e(isset($data['position'])?$data['position']:'right'); ?>" data-aos="fade" data-aos-duration="1200">
      <?php if(isset($data['text']['h1'])): ?>
        <h1><?php echo $data['text']['h1']; ?></h1>
      <?php endif; ?>
      <?php if(isset($data['text']['h2'])): ?>
        <h1><?php echo $data['text']['h2']; ?></h1>
      <?php endif; ?>
      <?php if(isset($data['text']['h3'])): ?>
        <h1><?php echo $data['text']['h3']; ?></h1>
      <?php endif; ?>
      <?php if(isset($data['text']['minus'])): ?>
        <?php echo $__env->make('components/minus', ['data' => $data['text']['minus']], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php endif; ?>
      <?php if(isset($data['text']['plus'])): ?>
        <?php echo $__env->make('components/plus', ['data' => $data['text']['plus']], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php endif; ?>
      <?php if(isset($data['text']['p'])): ?>
        <?php $__currentLoopData = $data['text']['p']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <p><?php echo e($paragraph); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </div>
  <?php endif; ?>
</section>