<section class="content-image-half">
  <div class="container">
    <div class="image" data-aos="fade-right">
      <img src="img/photo/<?php echo e($data['src']); ?>" alt="" />
    </div>
    <div class="text <?php echo e(isset($data['position'])?$data['position']:'right'); ?>" data-aos="fade-left">
      <?php if(isset($data['text']['h1'])): ?>
        <h1><?php echo $data['text']['h1']; ?></h1>
      <?php endif; ?>
      <?php if(isset($data['text']['h2'])): ?>
        <h1><?php echo $data['text']['h2']; ?></h1>
      <?php endif; ?>
      <?php if(isset($data['text']['h3'])): ?>
        <h1><?php echo $data['text']['h3']; ?></h1>
      <?php endif; ?>
      <?php if(isset($data['text']['minus'])): ?>
        <?php echo $__env->make('components/minus', ['data' => $data['text']['minus']], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php endif; ?>
      <?php if(isset($data['text']['plus'])): ?>
        <?php echo $__env->make('components/plus', ['data' => $data['text']['plus']], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php endif; ?>
    </div>
  </div>
</section>