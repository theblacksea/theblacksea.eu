<section class="content-image-embed">
  <div class="container">
    <div class="row">
      <div class="col-xs-12">
        <div class="image">
          <img src="<?php echo e(env('APP_PATH') .'img/articles/'. $data['src']); ?>" alt="" <?php echo e(isset($data['class']) ? 'class="' . $data['class'] .'"' : ''); ?> />
        </div>
        <?php if(isset($data['caption'])): ?>
          <div class="caption">
            <p><?php echo $data['caption']; ?></p>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>