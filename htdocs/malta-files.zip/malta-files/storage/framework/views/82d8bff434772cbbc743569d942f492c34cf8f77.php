<section class="content-subheadline">
  <div class="container">
    <div class="row">
      <div class="col-xs-12">
        <h2>
          <?php echo $data; ?>

        </h2>
      </div>
    </div>
  </div>
</section>