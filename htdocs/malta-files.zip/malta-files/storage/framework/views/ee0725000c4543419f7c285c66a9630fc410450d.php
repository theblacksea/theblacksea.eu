<div class="plus">
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p>
      <?php if($k == 0): ?>
        <span class="plus-sign">&plus;</span>
      <?php endif; ?>
      <?php echo $paragraph; ?>

    </p>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>