<section class="content-images-comparison">
  <div class="container">
    <div class="row no-gutters">
      <?php $__currentLoopData = $data['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6 image" style="background-image: url('img/photo/<?php echo e($image); ?>');" data-aos="fade"></div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="row no-gutters text">
      <div class="col-sm-6">
        <?php echo $__env->make('components/minus', ['data' => $data['text']['minus']], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
      <div class="col-sm-6">
        <?php echo $__env->make('components/plus', ['data' => $data['text']['plus']], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
    </div>
  </div>
</section>