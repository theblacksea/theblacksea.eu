<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $minus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="minus">
    <?php $__currentLoopData = $minus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <p>
        <?php if($k == 0): ?>
          <span class="minus-dash">&mdash;</span>
        <?php endif; ?>
        <?php echo $paragraph; ?>

      </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>